<?php

    return [

        'api_base_url' => 'http://49.12.94.243:7735/Exchange/hs/',
        'api_user' => 'wso',
        'api_password' => 'wso'
    ];

