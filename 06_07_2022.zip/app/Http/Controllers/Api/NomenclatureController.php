<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Supplier;
use App\Models\Category;
use App\Models\Nomenclature;
use App\Models\Balance;
use App\Models\TerritorialDivision;
use App\Models\Synchronization;

class NomenclatureController extends Controller
{   
    public function list()
    {
        $nomenclature = Nomenclature::with('balance')->get();

        if(empty($nomenclature)){
            return response()->json([
                'status' => 'error',
                'message' => 'There is no available nomenclature'
            ], 404);
        }

        return response()->json([
            'status' => 'ok',
            'nomenclature' => $nomenclature
        ], 200);
    }

    public function categoriesList()
    {
        $categories = Category::get();

        if(empty($categories)){
            return response()->json([
                'status' => 'error',
                'message' => 'There is no available categories'
            ], 404);
        }

        return response()->json([
            'status' => 'ok',
            'categories' => $categories
        ], 200);
    }

    public function suppliersList()
    {
        $suppliers = Supplier::get();

        if(empty($suppliers)){
            return response()->json([
                'status' => 'error',
                'message' => 'There is no available suppliers'
            ], 404);
        }

        return response()->json([
            'status' => 'ok',
            'suppliers' => $suppliers
        ], 200);
    }

    public function sync()
    {
		$needSync = false;
		
        $apiUrl = \Config::get('api.api_base_url');
        $apiUser = \Config::get('api.api_user');
        $apiPassword = \Config::get('api.api_password');

        $auth = base64_encode($apiUser . ":" . $apiPassword);
        $context = stream_context_create([
            "http" => [
                "header" => "Authorization: Basic " . $auth
            ]
        ]);

        //$result =  preg_replace('/[[:^print:]]/', '', file_get_contents($apiUrl . "Agents/GetSetOfGoods/", false, $context));
		$result =  file_get_contents($apiUrl . "Agents/GetSetOfGoods/", false, $context);
		$hash = md5($result);
        $prevSync = Synchronization::where('entity', 'Nomenclatures')->first();
		
		if(empty($prevSync)){
            $prevSync = new Synchronization();
            $prevSync->entity = "Nomenclatures";
            $prevSync->hash = md5($result);
            $prevSync->save();
            $needSync = true;
        } else {
            if($prevSync->hash === $hash){
                $needSync = false;
            } else {
                $needSync = true;
                $prevSync->hash = $hash;
                $prevSync->save();
            }
        }
		
		if($needSync){
			$data = json_decode($result, true);

			if(isset($data['Data']) && !empty($data['Data'])){
				foreach($data['Data'] as $group){

					$modelCategory = Category::where('guid', $group['Id'])->first();
					if(empty($modelCategory)){
						$modelCategory = new Category();
					}

					$modelCategory->guid = $group['Id'];
					$modelCategory->name = $group['Description'];
					if($modelCategory->save()){
						$modelSupplier = Supplier::where('guid', $group['Organization'][0]['Id'])->first();
						if(empty($modelSupplier)){
							$modelSupplier = new Supplier();
						}

						$modelSupplier->guid = $group['Organization'][0]['Id'];
						$modelSupplier->name =  $group['Organization'][0]['Description'];

						if($modelSupplier->save()){
							if(isset($group['Nomenclature']) && !empty($group['Nomenclature'])){
								foreach($group['Nomenclature'] as $nomenclature){
									$modelNomencature = Nomenclature::where('guid', $nomenclature['Id'])->first();
									if(empty($modelNomencature)){
										$modelNomencature = new Nomenclature();
									}

									$modelNomencature->guid = $nomenclature['Id'];
									$modelNomencature->category_id = $modelCategory->id;
									$modelNomencature->organization_id = $modelSupplier->id;
									$modelNomencature->name = $nomenclature['Description'];
									$modelNomencature->price = !empty($nomenclature['Price']) ? $nomenclature['Price'] : 0;
									$modelNomencature->unit = $nomenclature['Unit'];
									$modelNomencature->coef = $nomenclature['Coef'];
									$modelNomencature->color = $nomenclature['BackgroundColor'] ?? null;

									if($modelNomencature->save()){
										if(isset($nomenclature['Balance']) && !empty($nomenclature['Balance'])){
											foreach($nomenclature['Balance'] as $balance){
												$territorialDivision = TerritorialDivision::where('guid', $balance['Id'])->first();

												$balanceModel = Balance::where(['division_id' => $territorialDivision->id, 'nomenclature_id' => $modelNomencature->id])->first();
												if(empty($balanceModel)){
													$balanceModel = new Balance();
												}

												$balanceModel->division_id = $territorialDivision->id;
												$balanceModel->division_guid = $territorialDivision->guid;
												$balanceModel->nomenclature_id = $modelNomencature->id;
												$balanceModel->nomenclature_guid = $modelNomencature->guid;
												$balanceModel->quantity = $balance['Balance'];

												$balanceModel->save();
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
    }
}